﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_2
{
    public partial class fmProtocolo : Form
    {
        public fmProtocolo()
        {
            InitializeComponent();
        }

        public void LlenarCombos()
        {
            cbCarrera.DataSource = null;
            cbCarrera.DataSource = Declaraciones.LEstudiantes;
            cbCarrera.DisplayMember = "Carrera";
            cbCarrera.ValueMember = "Carrera";


            cbTutor.DataSource = null;
            cbTutor.DataSource = Declaraciones.LProfesores;
            cbTutor.DisplayMember = "Nombres";
            cbTutor.ValueMember = "Nombres";


        }
        private void btnInsertar_Click(object sender, EventArgs e)
        {
            Declaraciones.LProfesores.Add
                (
                new Profesor
                {
                    Tutor = (cbTutor.SelectedValue.ToString())
                }
                );


            Declaraciones.LEstudiantes.Add
                (
                new Estudiante
                {
                    Carrera = (cbCarrera.SelectedValue.ToString())
                }
                );
            dgProtocolo.DataSource = null;
            dgProtocolo.DataSource = Declaraciones.LProfesores;
            dgProtocolo.DataSource = Declaraciones.LEstudiantes;
        }

        private void fmProtocolo_Load(object sender, EventArgs e)
        {

        }

    }
}
