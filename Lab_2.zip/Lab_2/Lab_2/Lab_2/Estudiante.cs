﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_2
{
    class Estudiante : Persona
    {
        public int Carnet { get; set; }
        public string Carrera { get; set; }


        List<String> LCarreras = new List<String>();

        public Estudiante()
        {
            LCarreras.Add("Computacion");
            LCarreras.Add("Electrica");
            LCarreras.Add("Electronica");
            LCarreras.Add("Arquitectura");
            LCarreras.Add("Quimica");
        }
        public List<string> OLCarreras()
        {
            return LCarreras;
        }

    }

    
}
