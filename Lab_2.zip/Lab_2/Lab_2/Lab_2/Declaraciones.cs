﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_2
{
    static class Declaraciones
    {
        public static List<Estudiante> LEstudiantes = new List<Estudiante>();
        public static List<Profesor> LProfesores = new List<Profesor>();
    }
}
