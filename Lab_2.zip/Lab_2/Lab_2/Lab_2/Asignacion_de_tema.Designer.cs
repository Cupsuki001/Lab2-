﻿
namespace Lab_2
{
    partial class Asignacion_de_tema
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtTema = new System.Windows.Forms.TextBox();
            this.cbAGrupo = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dgAgregarTema = new System.Windows.Forms.DataGridView();
            this.btnAgregar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgAgregarTema)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tema";
            // 
            // txtTema
            // 
            this.txtTema.Location = new System.Drawing.Point(73, 56);
            this.txtTema.Name = "txtTema";
            this.txtTema.Size = new System.Drawing.Size(100, 20);
            this.txtTema.TabIndex = 1;
            // 
            // cbAGrupo
            // 
            this.cbAGrupo.FormattingEnabled = true;
            this.cbAGrupo.Location = new System.Drawing.Point(73, 96);
            this.cbAGrupo.Name = "cbAGrupo";
            this.cbAGrupo.Size = new System.Drawing.Size(121, 21);
            this.cbAGrupo.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Grupo";
            // 
            // dgAgregarTema
            // 
            this.dgAgregarTema.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgAgregarTema.Location = new System.Drawing.Point(225, 56);
            this.dgAgregarTema.Name = "dgAgregarTema";
            this.dgAgregarTema.Size = new System.Drawing.Size(457, 153);
            this.dgAgregarTema.TabIndex = 4;
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(73, 168);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(75, 23);
            this.btnAgregar.TabIndex = 5;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.UseVisualStyleBackColor = true;
            this.btnAgregar.Click += new System.EventHandler(this.btnAgregar_Click);
            // 
            // Asignacion_de_tema
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 282);
            this.Controls.Add(this.btnAgregar);
            this.Controls.Add(this.dgAgregarTema);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cbAGrupo);
            this.Controls.Add(this.txtTema);
            this.Controls.Add(this.label1);
            this.Name = "Asignacion_de_tema";
            this.Text = "Asignacion_de_tema";
            ((System.ComponentModel.ISupportInitialize)(this.dgAgregarTema)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTema;
        private System.Windows.Forms.ComboBox cbAGrupo;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dgAgregarTema;
        private System.Windows.Forms.Button btnAgregar;
    }
}