﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_2
{
    public partial class fmEstudiantes : Form
    {
        public fmEstudiantes()
        {
            InitializeComponent();
        }


        private void btnInsertar_Click(object sender, EventArgs e)
        {
            Declaraciones.LEstudiantes.Add
                (
                new Estudiante
                {
                    Carnet = int.Parse(txtCarnet.Text),
                    Nombres = txtNombres.Text,
                    Apellidos = txtApellidos.Text,
                    FechaN = DateTime.Parse(dtAñoNac.Text),
                    Carrera = cbCarrera.Text,
                }
                );
            dgREstudiante.DataSource = null;
            dgREstudiante.DataSource = Declaraciones.LEstudiantes;

        }

        private void fmEstudiantes_Load(object sender, EventArgs e)
        {
            Estudiante C = new Estudiante();
            cbCarrera.DataSource = C.OLCarreras();
        }
    }
}
