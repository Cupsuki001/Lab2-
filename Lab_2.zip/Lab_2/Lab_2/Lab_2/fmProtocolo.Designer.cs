﻿
namespace Lab_2
{
    partial class fmProtocolo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtCantidadE = new System.Windows.Forms.TextBox();
            this.cbCarrera = new System.Windows.Forms.ComboBox();
            this.btnInsertar = new System.Windows.Forms.Button();
            this.cbTutor = new System.Windows.Forms.ComboBox();
            this.dgProtocolo = new System.Windows.Forms.DataGridView();
            this.txtIngreseTem = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dtFechaEntregaRe = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.txtDocenteRe = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cbEstado = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgProtocolo)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(48, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tema";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 148);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Cantidad de Estudiantes";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(45, 189);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Tutor";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(48, 67);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Carrera";
            // 
            // txtCantidadE
            // 
            this.txtCantidadE.Location = new System.Drawing.Point(171, 148);
            this.txtCantidadE.Name = "txtCantidadE";
            this.txtCantidadE.Size = new System.Drawing.Size(120, 20);
            this.txtCantidadE.TabIndex = 8;
            // 
            // cbCarrera
            // 
            this.cbCarrera.FormattingEnabled = true;
            this.cbCarrera.Location = new System.Drawing.Point(170, 64);
            this.cbCarrera.Name = "cbCarrera";
            this.cbCarrera.Size = new System.Drawing.Size(121, 21);
            this.cbCarrera.TabIndex = 9;
            // 
            // btnInsertar
            // 
            this.btnInsertar.Location = new System.Drawing.Point(191, 281);
            this.btnInsertar.Name = "btnInsertar";
            this.btnInsertar.Size = new System.Drawing.Size(75, 23);
            this.btnInsertar.TabIndex = 11;
            this.btnInsertar.Text = "Insertar";
            this.btnInsertar.UseVisualStyleBackColor = true;
            this.btnInsertar.Click += new System.EventHandler(this.btnInsertar_Click);
            // 
            // cbTutor
            // 
            this.cbTutor.FormattingEnabled = true;
            this.cbTutor.Location = new System.Drawing.Point(170, 189);
            this.cbTutor.Name = "cbTutor";
            this.cbTutor.Size = new System.Drawing.Size(121, 21);
            this.cbTutor.TabIndex = 12;
            // 
            // dgProtocolo
            // 
            this.dgProtocolo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgProtocolo.Location = new System.Drawing.Point(335, 107);
            this.dgProtocolo.Name = "dgProtocolo";
            this.dgProtocolo.Size = new System.Drawing.Size(487, 233);
            this.dgProtocolo.TabIndex = 13;
            // 
            // txtIngreseTem
            // 
            this.txtIngreseTem.Location = new System.Drawing.Point(170, 29);
            this.txtIngreseTem.Name = "txtIngreseTem";
            this.txtIngreseTem.Size = new System.Drawing.Size(120, 20);
            this.txtIngreseTem.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(332, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(145, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "Fecha de entrega de revision";
            // 
            // dtFechaEntregaRe
            // 
            this.dtFechaEntregaRe.Location = new System.Drawing.Point(483, 29);
            this.dtFechaEntregaRe.Name = "dtFechaEntregaRe";
            this.dtFechaEntregaRe.Size = new System.Drawing.Size(200, 20);
            this.dtFechaEntregaRe.TabIndex = 16;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(45, 104);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 13);
            this.label7.TabIndex = 20;
            this.label7.Text = "Docentes revisores";
            // 
            // txtDocenteRe
            // 
            this.txtDocenteRe.Location = new System.Drawing.Point(171, 104);
            this.txtDocenteRe.Name = "txtDocenteRe";
            this.txtDocenteRe.Size = new System.Drawing.Size(119, 20);
            this.txtDocenteRe.TabIndex = 19;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(48, 236);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 13);
            this.label6.TabIndex = 21;
            this.label6.Text = "Estado";
            // 
            // cbEstado
            // 
            this.cbEstado.FormattingEnabled = true;
            this.cbEstado.Location = new System.Drawing.Point(170, 236);
            this.cbEstado.Name = "cbEstado";
            this.cbEstado.Size = new System.Drawing.Size(121, 21);
            this.cbEstado.TabIndex = 22;
            // 
            // fmProtocolo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(861, 411);
            this.ControlBox = false;
            this.Controls.Add(this.cbEstado);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtDocenteRe);
            this.Controls.Add(this.dtFechaEntregaRe);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtIngreseTem);
            this.Controls.Add(this.dgProtocolo);
            this.Controls.Add(this.cbTutor);
            this.Controls.Add(this.btnInsertar);
            this.Controls.Add(this.cbCarrera);
            this.Controls.Add(this.txtCantidadE);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "fmProtocolo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "fmProtocolo";
            this.Load += new System.EventHandler(this.fmProtocolo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgProtocolo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtCantidadE;
        private System.Windows.Forms.ComboBox cbCarrera;
        private System.Windows.Forms.Button btnInsertar;
        private System.Windows.Forms.ComboBox cbTutor;
        private System.Windows.Forms.DataGridView dgProtocolo;
        private System.Windows.Forms.TextBox txtIngreseTem;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DateTimePicker dtFechaEntregaRe;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtDocenteRe;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cbEstado;
    }
}