﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_2
{
    class Protocolo
    {
        public string Tema { get; set; }
        public DateTime FechaEntrega { get; set; }
        public string Facultad { get; set; }
        public string Carrera { get; set; }
        public Profesor Tutor { get; set; }
        public List<Profesor> Revisores { get; set; }
        public List<Estudiante> Estudiantes { get; set; }
        public enum Estado { Aprobado, EnRevision, NoAprobado }
        public Estado EstadoProtocolo { get; set; }

    }
}
