﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        fmEstudiantes Est = new fmEstudiantes();
        FmProfesor Po = new FmProfesor();
        fmProtocolo Pro = new fmProtocolo();

        private void registroEstudianteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Est.MdiParent = this;
            Est.Show();

            Po.Hide();
            Pro.Hide();

        }

        private void registroProfesoresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Po.MdiParent = this;
            Po.Show();

            Est.Hide();
            Pro.Hide();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void registroProtocoloToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Pro.MdiParent = this;
            Pro.Show();

            Est.Hide();
            Po.Hide();
        }
    }
}
