﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_2
{
    class Profesor: Persona
    {
        public string Departamento { get; set; }
        List<string> LDepartamentos = new List<string>();
        public string Tutor { get; set; }

        public Profesor()
        {
            LDepartamentos.Add("Lenguaje y Simulación");
            LDepartamentos.Add("Arquitectura y Sistemas de Aplicación");
        }

        public List<string> OLDepartamentos()
        {
            return LDepartamentos;
        }
    }
}
