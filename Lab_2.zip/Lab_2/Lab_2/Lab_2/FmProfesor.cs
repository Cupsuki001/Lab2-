﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_2
{
    public partial class FmProfesor : Form
    {
        public FmProfesor()
        {
            InitializeComponent();
        }

        private void btnInsertar_Click(object sender, EventArgs e)
        {
            Declaraciones.LProfesores.Add
                (
                new Profesor
                {
                    Nombres = txtNombres.Text,
                    Apellidos = txtApellidos.Text,
                    FechaN = DateTime.Parse(dtFechaN.Text),
                    Departamento = cbDepartamento.Text
                }
                );
            dgProfesores.DataSource = null;
            dgProfesores.DataSource = Declaraciones.LProfesores;
        }

        private void FmProfesor_Load(object sender, EventArgs e)
        {
            Profesor P = new Profesor();
            cbDepartamento.DataSource = null;
            cbDepartamento.DataSource = P.OLDepartamentos();
        }
    }
}
